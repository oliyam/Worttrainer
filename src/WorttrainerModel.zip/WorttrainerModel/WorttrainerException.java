package WorttrainerModel;
/**
 * Klasse f�r die WorttrainerException
 * 
 * @author oli
 *
 */
public class WorttrainerException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public WorttrainerException(String msg) {
		super(msg);
	}
}
